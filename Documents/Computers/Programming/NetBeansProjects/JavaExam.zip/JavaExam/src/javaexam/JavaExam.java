/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaexam;

import GUI.FrontGUI;

/**
 *
 * @author Ari
 */
public class JavaExam {

    public static void main(String[] args) {
       FrontGUI menu = new FrontGUI();
menu.main(null);
    }

}
