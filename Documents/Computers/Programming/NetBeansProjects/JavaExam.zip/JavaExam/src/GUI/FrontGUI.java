package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author [Student]
 */
public class FrontGUI extends JFrame {

    //create all the required components and variables
    private JPanel high, crust, toppings, southPanel;
    private JButton exitButton, calculateButton;
    private JCheckBox addTaxCheckBox;
    private JTextField costTextField;
    private JLabel costLabel;

    //constructor
    public FrontGUI() {
        //set title, close operation and the required layout
        super("Order Calculator");
        setLayout(new BorderLayout());

        //create panels
        JPanel crust = new PizzaCrustPanel();
        JPanel toppings = new PizzaToppingsPanel();
        JPanel high = new PizzaHouseGreetingsPanel();

        add(high, BorderLayout.NORTH);
        add(crust, BorderLayout.WEST);
        add(toppings, BorderLayout.EAST);

        //call a method to build the bottom panel
        //that contains all the required components
        buildButtonPanel();
        add(southPanel, BorderLayout.SOUTH);

    }

    //enable a way to build the bottom panel and all the required components
    //ensure to add all required event listeners. Event listeners can either 
    //be inner, private classes OR anonymous classes. 
    private void buildButtonPanel() {
        southPanel = new JPanel();
        
        costLabel = new JLabel("Total:");
        
        costTextField = new JTextField(7);

        addTaxCheckBox = new JCheckBox("Add Tax");
        addTaxCheckBox.addActionListener(new AddTaxCheckBoxButtonHandler());

        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(new CalculateButtonHandler());

        exitButton = new JButton("Exit");
        exitButton.addActionListener(new ExitButtonHandler());

        southPanel.add(costLabel);
        southPanel.add(costTextField);
        southPanel.add(addTaxCheckBox);
        southPanel.add(calculateButton);
        southPanel.add(exitButton);
    }

    private class ExitButtonHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            System.exit(0);
        }
    }

    private class CalculateButtonHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            System.exit(0);

        }
    }

    private class AddTaxCheckBoxButtonHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            System.exit(0);

        }
    }

    public static void main(String[] args) {
        FrontGUI gui = new FrontGUI();
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.pack();
        gui.setVisible(true);
    }
}
