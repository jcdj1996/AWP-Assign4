package GUI;
import javax.swing.*;
/**
 *
 * @author [student]
 */
public class PizzaHouseGreetingsPanel extends JPanel
{
    private JLabel lblGreeting;
    
    public PizzaHouseGreetingsPanel()
    {
        //create a label for the main frame
        lblGreeting = new JLabel ("Welcome to Kirby's Pizza");
        add(lblGreeting);
    }        
}
