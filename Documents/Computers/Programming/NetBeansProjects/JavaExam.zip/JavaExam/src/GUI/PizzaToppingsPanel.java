package GUI;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author [Student]
 */
public class PizzaToppingsPanel extends JPanel {

    public double EXTRA_CHEESE = 2.00, GREEN_OLIVES = 2.00,
            PEPPERONI = 1.50, HAM = 1.50;

    private JCheckBox extraCheese, greenOlives, pepperoni, ham;

    public PizzaToppingsPanel() {
        //set an appropriate layout
        setLayout(new GridLayout(4,1));
        //initialize the components
        extraCheese = new JCheckBox("Extra Cheese");
        greenOlives = new JCheckBox("Green Olives");
        pepperoni = new JCheckBox("Pepperoni");
        ham = new JCheckBox("Ham");

        add(extraCheese);
        add(greenOlives);
        add(pepperoni);
        add(ham);

        //create a border
        setBorder(BorderFactory.createTitledBorder("Toppings"));
    }//end of main

    //enable the cost to be available from this class
}
