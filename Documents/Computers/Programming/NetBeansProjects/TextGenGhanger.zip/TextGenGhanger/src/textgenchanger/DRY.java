/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package textgenchanger;

/**
 *
 * @author Ari
 */
public class DRY {
    
    /**
     * removeChar will (r)emove (a)ny (c)haracter.
     *
     * @param s - string to be converted
     * @param c - character to be removed
     * @return
     */
    public static String removeChar(String s, char c) {
        String answer = "";
        int i = -1;
        while (++i < s.length()) {
            if (s.charAt(i) != c) {
                answer += s.charAt(i);
            }
        }
        return answer;
    }

    /**
     * a will (a)dd (a)ny (c)haracter
     *
     * @param s - string to be altered
     * @param c - character to be inserted
     * @param a - character which @param c will follow
     * @return
     */
    public static String addChar(String s, char c, char a) {
        String answer = "";
        int i = -1;
        while (++i < s.length()) {
            if (i != 0 && s.charAt(i - 1) == a) {
                answer += c;
            }
            answer += s.charAt(i);
        }
        return answer;
    }

    /**
     * exchangeChar will e(x)change (a)ny (c)haracter
     *
     * @param s - string to be changed
     * @param t - character to target
     * @param x - character to exchange
     * @return
     */
    public static String exchangeChar(String s, char t, char x) {
        String answer = "";
        int i = -1;
        while (++i < s.length()) {
            if (s.charAt(i) == t) {
                answer += x;
            } else {
                answer += s.charAt(i);
            }
        }
        return answer;
    }

    /**
     * flipChar flips information around a colon
     *
     * @param s - string to be modified
     * @param c - char to flip on
     * @return
     */
    public static String flipChar(String s, char c) {
        String answer = "";
        String leftSide;
        String rightSide;
        int j;
        int add = 0;
        for (int i = 0; i < s.length(); i++) {
            leftSide = null;
            rightSide = null;
            if (s.charAt(i) == c) {
                j = i - 1;
                while (--j >= 0) {
                    if (j != 0 && s.charAt(j - 1) == ' ') {
                        break;
                    }
                    leftSide = s.substring((j - 1 < 0) ? 0 : j - 1, i);
                }
                j = i + 1;
                while (++j <= s.length()) {
                    if (s.charAt(j - 1) == ' ') {
                        break;
                    }
                    rightSide = s.substring(i + 1, j);
                    add = j - i + 1;

                }
                answer += rightSide + c + leftSide + " ";
                i += add;
            }
        }
        return answer;
    }

    /**
     * replaceSeq will exchange a character for a sequence of characters
     *
     * @param s - the String to modify
     * @param t - the character to select
     * @return the modified string
     */
    public static String replaceSeq(String s, char t) {
        String answer = "";
        int i = -1;
        int j = 0;
        while (++i < s.length()) {
            if (s.charAt(i) == t) {
                j = i - 1;
                while (s.charAt(++j) != ' ') {
                    answer += s.charAt(j);
                }
            } else {
                answer += s.charAt(i);
            }
        }

        return answer;
    }

    /**
     * replaceSeq will exchange a character for a sequence of characters
     *
     * @param s - the String to modify
     * @param t - the character to select
     * @param seqReplace - the sequence replacement
     * @return the modified string
     */
    public static String replaceSeq(String s, char t, String seqReplace) {
        String answer = "";
        int i = -1;
        int j = 0;
        while (++i < s.length()) {
            if (s.charAt(i) == t) {
                j = i - 1;
                while (s.charAt(++j) != ' ') {
                    answer += s.charAt(j);
                }
                answer += seqReplace;
            } else {
                answer += s.charAt(i);
            }
        }
        return answer;
    }

    /**
     * createVaribales changes input text to Java variables declaration
     *
     * @param s - the string to be converted
     * @return the modified String
     */
    public static String createVaribales(String s) {

        //for input formatting
        //remove newline, space, and  then exchange space for comma
        s = removeChar(s, '\n');
        s = removeChar(s, ' ');
        s = exchangeChar(s, ',', ' ');

        //flip on colon
        s = flipChar(s, ':');

        //variable formatting
        //exchange space for semicolon
        s = exchangeChar(s, ' ', ';');
        // exchange colon for space
        s = exchangeChar(s, ':', ' ');
        //add newline
        s = addChar(s, '\n', ';');

        //return modified;
        return s;
    }

    public static String createConstructorVaribales(String s, String className) {
        String s2 = s;
        //for input formatting
        //remove newline, space, and then exchange space for comma
        s = removeChar(s, '\n');
        s = removeChar(s, ' ');
        s = exchangeChar(s, ',', ' ');

        //flip on colon
        s = flipChar(s, ':');

        //constructor formatting
        //exchange space for comma
        s = exchangeChar(s, ' ', ',');
        // exchange colon for space
        s = exchangeChar(s, ':', ' ');
        //remove last comma
        if (s.charAt(s.length() - 1) == ',') {
            s = s.substring(0, s.length() - 1);
        }
        //Wrapping
        s = "public " + className + "(" + s + "){" + thisDot(s2) + "}";
        //return modified;
        return s;
    }

    /**
     * thisDot will change an input to this.variableName = variableName format
     *
     * @param s - string to modify
     * @return - modified string
     */
    public static String thisDot(String s) {
        //remove ' ', '\n', '[', and ']'
        s = removeChar(s, ' ');
        s = removeChar(s, '[');
        s = removeChar(s, ']');
        s = removeChar(s, '\n');

        //exchange for flipping
        s = exchangeChar(s, ',', ' ');

        //flip colon       
        s = flipChar(s, ':');

        //replace var labels
        int i = -1;
        int j = 0;
        String temp = "";
        String varName;

        while (++i < s.length()) {
            if (s.charAt(i) == ' ') {
                j = i;
                while (--j > 0 && s.charAt(j) != ':') {
                }
                varName = s.substring(j + 1, i);
                //temp += "\tthis." + varName + " = " + varName + ";\n";
                temp += "\tset" + varName.toUpperCase().charAt(0) + varName.substring(1) + "(" + varName + ");\n";
                temp += "\tget" + varName.toUpperCase().charAt(0) + varName.substring(1) + "();\n";

            }
        }
        return temp;
    }
}
