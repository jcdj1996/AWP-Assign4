/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package textgenchanger;

/**
 *
 * @author Ari
 */
public class LikeJSON {

    String s;
    String[][] sJSON;

    public LikeJSON(String s) {
        int numPairs = 0;
        this.s = removeChar(s, ' ');
        int i = - 1;
        while (++i < this.s.length()) {
            if (this.s.charAt(i) == ':') {
                numPairs++;
            } else if (this.s.charAt(i) == ' ') {
                System.out.println("I should not be at location " + i);
            }
        }
        this.sJSON = new String[numPairs][2];
        numPairs = 0;
        i = -1;
        int j;
        while (++i < this.s.length()) {
            if (this.s.charAt(i) == ':') {
                j = i;
                while (--j >= 0 && (Character.isLetterOrDigit(this.s.charAt(j)) || this.s.charAt(j) == '[' || this.s.charAt(j) == ']')) {
                }
                this.sJSON[numPairs][0] = this.s.substring(j + 1, i);
                j = i;
                while (++j < this.s.length() && (Character.isLetterOrDigit(this.s.charAt(j)) || this.s.charAt(j) == '[' || this.s.charAt(j) == ']')) {
                }
                this.sJSON[numPairs][1] = this.s.substring(i + 1, j);
                numPairs++;
            }
        }
    }

    /**
     *
     * @return message of the array
     */
    @Override
    public String toString() {
        String message = "";
        for (int i = 0; i < this.sJSON.length; i++) {
            message += "\"" + this.sJSON[i][0] + "\" : \"" + this.sJSON[i][1] + "\"\n";
        }

        return message;
    }

    /**
     *
     * @return - no quotes message
     */
    public String toString2() {
        String message = "";
        for (int i = 0; i < this.sJSON.length; i++) {
            message += this.sJSON[i][0] + " : " + this.sJSON[i][1] + "\n";
        }
        return message;
    }
        /**
     *
     * @return - no quotes message
     */
    public String toString3() {
        String message = "";
        for (int i = 0; i < this.sJSON.length; i++) {
            message += this.sJSON[i][1] + ":" + this.sJSON[i][0] + ", ";
        }
        return message;
    }

    /**
     * removeChar will (r)emove (a)ny (c)haracter.
     *
     * @param s - string to be converted
     * @param c - character to be removed
     * @return
     */
    public static /*final*/ String removeChar(String s, char c) {
        String answer = "";
        int i = -1;
        while (++i < s.length()) {
            if (s.charAt(i) != c) {
                answer += s.charAt(i);
            }
        }
        return answer;
    }

}
