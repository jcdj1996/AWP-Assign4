package textgenchanger;

/**
 *
 * @author Ari `
 */
public class TextGenChanger {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String c = "partNumber:String,\n"
                + "partDescription:String,\n"
                + "supplier:String,\n"
                + "supplierPartNumber:String,\n"
                + "supplierDescription,\n"
                + "unitOfMeasure:String,\n"
                + "costDollar:int\n"
                + "costCents:int,\n"
                + "drawing:File,\n"
                + "materialDataSheet:File";
        //System.out.format("%s%n%n%s%n%n", "Original", c);

        LikeJSON lJ = new LikeJSON(c);
        //System.out.format("%s%n", lJ.toString()); 
        //System.out.format("%s", lJ.toString2());
        String className = "Product";
        System.out.format("public class %s {%n", className);
        int i = -1;
        while (++i < lJ.sJSON.length) {
            System.out.format("%s %s;%n",
                    lJ.sJSON[i][1],
                    lJ.sJSON[i][0]
            );
        }

        System.out.format("public %s (", className);
        i = -1;
        while (++i < lJ.sJSON.length) {
            System.out.format("%s %s%s",
                    lJ.sJSON[i][1],
                    lJ.sJSON[i][0],
                    i + 1 == lJ.sJSON.length ? "" : ", "
            );
        }
        System.out.format("){%n");
        i = -1;
        while (++i < lJ.sJSON.length) {
            System.out.format("\tthis.%s = %s;%n", lJ.sJSON[i][0], lJ.sJSON[i][0], i + 1 == lJ.sJSON.length ? "" : ", ");
        }
        System.out.format("}%n");
        i = -1;
        while (++i < lJ.sJSON.length) {
            System.out.format("public void set%s%s(%s %s){%n",
                    Character.toUpperCase(lJ.sJSON[i][0].charAt(0)),
                    lJ.sJSON[i][0].substring(1),
                    lJ.sJSON[i][1],
                    lJ.sJSON[i][0]
            );
            System.out.format("\tthis.%s = %s;%n",
                    lJ.sJSON[i][0],
                    lJ.sJSON[i][0]
            );
            System.out.format("}%n");
            System.out.format("public %s get%s%s(){%n",
                    lJ.sJSON[i][1],
                    Character.toUpperCase(lJ.sJSON[i][0].charAt(0)),
                    lJ.sJSON[i][0].substring(1)
            );
            System.out.format("\treturn this.%s;%n",
                    lJ.sJSON[i][0]
            );
            System.out.format("}%n");
        }
        System.out.format("}%n");

        i = -1;
        while (++i < lJ.sJSON.length) {
            System.out.format("+set%s%s(%s:%s)%n",
                    Character.toUpperCase(lJ.sJSON[i][0].charAt(0)),
                    lJ.sJSON[i][0].substring(1),
                    lJ.sJSON[i][0],
                    lJ.sJSON[i][1]
            );
            System.out.format("+get%s%s()%n",
                    Character.toUpperCase(lJ.sJSON[i][0].charAt(0)),
                    lJ.sJSON[i][0].substring(1)
            );
        }
        System.out.format(lJ.toString3());

        //Variable Style
        //System.out.format("%s%n%n%s%n%n", "Variable Style", createVaribales(c));
        //Contructor Style 
        //System.out.format("%s%n%n%s%n%n", "Contructor Style", createConstructorVaribales(c, "Employee"));
        //this. Style
        //System.out.format("%s%n%n%s%n%n", "this. Style", thisDot(c));
        //Program
        //System.out.format("%s%n%s%n", createVaribales(c), createConstructorVaribales(c, "Employee"));
    }

    

}
