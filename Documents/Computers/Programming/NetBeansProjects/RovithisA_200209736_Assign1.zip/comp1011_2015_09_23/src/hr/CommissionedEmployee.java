package hr;

import AristotleToolBox.Check;
import AristotleToolBox.DRY;
import AristotleToolBox.EntityInformation;

/**
 *
 * @author Ari
 */
public class CommissionedEmployee extends Employee {

    private double commissionRate = 0;
    private int salesDollar = 0;
    private int salesCents = 0;
    private int payDollar = 0;
    private int payCents = 0;

    public CommissionedEmployee() {
        super();
    }

    public CommissionedEmployee(String firstName, String lastName, String unitNumber,
            int streetNumber, String streetName, String streetType, String city,
            String stateOrProvince, String postal, String gender,
            String maritialStatus, String birthday, String phoneNumber,
            String email, String socialInsuranceNumber, String hireDate,
            String termination, String jobTitle,
            String jobDescription, double commissionRate,
            int salesDollar, int salesCents) {
        super(firstName, lastName, unitNumber,
                streetNumber, streetName, streetType, city,
                stateOrProvince, postal, gender,
                maritialStatus, birthday, phoneNumber,
                email, socialInsuranceNumber, hireDate,
                termination, jobTitle,
                jobDescription);
        this.setCommissionRate(commissionRate);
        this.setSalesDollar(salesDollar);
        this.setSalesCents(salesCents);
        this.calculateEarnings();

    }

    public final double getCommissionRate() {
        return commissionRate;
    }

    public final int getSalesDollar() {
        return salesDollar;
    }

    public final int getSalesCents() {
        return salesCents;
    }

    public final int getPayDollar() {
        return payDollar;
    }

    public final int getPayCents() {
        return payCents;
    }

    public final boolean setCommissionRate(double commissionRate) {
        if (commissionRate >= 0 && commissionRate <= 1) {
            this.commissionRate = commissionRate;
            return true;
        }
        return false;
    }

    public final boolean setSalesDollar(int salesDollar) {
        if (Check.isWholeNumber(salesDollar)) {
            this.salesDollar = salesDollar;
            return true;
        }
        return false;
    }

    public final boolean setSalesCents(int salesCents) {
        if (Check.isWholeNumber(salesCents)) {
            this.salesCents = salesCents;
            return true;
        }
        return false;
    }

    public final boolean setPayDollar(int payDollar) {
        if (Check.isWholeNumber(payDollar)) {
            this.payDollar = payDollar;
            return true;
        }
        return false;
    }

    public final boolean setPayCents(int payCents) {
        if (Check.isWholeNumber(payCents)) {
            this.payCents = payCents;
            return true;
        }
        return false;
    }

    public final int[] getCommission() {
        return new int[]{(int) (this.getCommissionRate() * this.getSalesDollar()),
            (int) (this.getCommissionRate() * this.getSalesCents())};
    }

    /**
     * output all information about the employee with a String.format message
     *
     * @return all information center justified
     */
    @Override
    public final String toString() {
        return String.format("%s%n" //original
                + "%18s%s%n" //commisionRate
                + "%18s%s%n" //sales
                + "%18s%s%n" //commission
                + "%18s%s%n", //total pay
                super.toString(),
                "Commission Rate: ", this.getCommissionRate(),
                "Sales: ", EntityInformation.changeMoneyToString(new int[]{this.getSalesDollar(), this.getSalesCents()}),
                "Commission: ", EntityInformation.changeMoneyToString(EmpUtility.formatMoney(this.getCommission()[0], this.getCommission()[1])),
                "Total pay: ", EntityInformation.changeMoneyToString(new int[]{this.getEarnings()[0], this.getEarnings()[1]})
        );
    }

    @Override
    public final boolean calculateEarnings() {
        if ((getSalesCents() != 0 || getSalesDollar() != 0) && getCommissionRate() != 0) {
            setPayDollar((int) ((double) getSalesDollar() * getCommissionRate()));
            setPayCents((int) ((double) getSalesCents() * getCommissionRate()));
            int[] carrier = EmpUtility.formatMoney(getPayDollar(), getPayCents());
            setPayDollar(carrier[0]);
            setPayCents(carrier[1]);
            return true;
        }
        if (getSalesCents() == 0 && getSalesDollar() == 0) {
            DRY.errorMsg(new String[]{"You have entered $0.00 in sales", "No Sales"});
        }
        if (getCommissionRate() == 0) {
            DRY.errorMsg(new String[]{"You have entered 0% as Commission", "No Commission"});
        }
        return false;
    }

    @Override
    public final int[] getEarnings() {
        return new int[]{getPayDollar(), getPayCents()};
    }
}
