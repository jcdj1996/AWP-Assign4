package hr;

import AristotleToolBox.*;
import hr.HourlyEmployee.*;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Ari
 */
public class EmpUtility {

    // CLASS CONSTANTS **************************************************************************
    private static final String[] SHORT_GENDER_LIST = {
        "M", "F", "ND"
    };

    private static final String[] LONG_GENDER_LIST = {
        "MALE", "FEMALE", "NOT DISCLOSED"
    };

    private static final String[] MARITIAL_STATUS_LIST = {
        "Single", "Married", "Common-Law", "Widowed", "Seperated", "Divorced",};

    // CLASS VARIABLES **********************************************************************
    public static int counter = 1000;

    // CLASS FUNCTIONS **********************************************************************
    public static int incrementEmpID() {
        return ++counter;
    }

    // HELPER METHODS **********************************************************************
    /**
     * changes the gender to ensure it is in the short form
     *
     * @param gender the gender to be checked
     * @return the short gender form, else ""
     */
    public static String changeGender(String gender) {
        for (String g : SHORT_GENDER_LIST) {
            if (gender.equals(g)) {
                return gender;
            }
        }
        for (String g : LONG_GENDER_LIST) {
            if (gender.equals(g)) {
                return SHORT_GENDER_LIST[Arrays.asList(LONG_GENDER_LIST).indexOf(g)];
            }
        }
        return "";
    }

    /**
     * checks to see if the marital status is legitimately matching with the static list
     *
     * @param status the status to be compared
     * @return the status if it matches the list, else ""
     */
    public static String checkMS(String status) {
        for (String m : MARITIAL_STATUS_LIST) {
            if (status.equals(m)) {
                return status;
            }
        }
        return "";
    }

    public static Employee findEmployee(ArrayList<Employee> list, Class c) {
        for (Employee emp : list) {
            if (emp.toString().contains(c.getClass().getGenericSuperclass().toString())) {
                return emp;
            }
        }
        return null;
    }

    public static final int[] formatMoney(int dollars, int cents) {
        if (Check.isWholeNumber(dollars) && Check.isWholeNumber(cents)) {
            if (cents >= 100) {
                DRY.errorMsg(new String[]{"you gave me " + cents + " thats "
                    + "equal to $" + cents / 100 + "." + cents % 100 + ", I "
                    + "have automatically transfered the amount dollar amount "
                    + "for you.",
                    "Cents Overflow Error"});
                dollars += cents / 100;
                cents %= 100;
            }
            return new int[]{dollars, cents};
        }
        DRY.errorMsg(new String[]{"You have to enter a monetary value greater than 0", "Negative cent value Entered"});
        return new int[]{0, 0};
    }

    //COMMON EMPLOYEE CREATOR
    private static void createTeamMember(Employee employee) { //GLARING YELLOW METHOD!
        //FIRST NAME
        while (!employee.setFirstName(DRY.requestSpecificAnswer("Please enter your first name")));
        //LAST NAME
        while (!employee.setLastName(DRY.requestSpecificAnswer("Please enter your last name")));
        //GENDER 
        while (!employee.setGender(DRY.requestSpecificAnswerUX("Please enter your gender", "M, F, ND").toUpperCase()));
        //ADDRESS STREET NUMBER
        while (!employee.setStreetNumber(DRY.requestInteger("Please enter your street number", 1, Integer.MAX_VALUE)));
        //ADDRESS STREET NAME
        while (!employee.setStreetName(DRY.requestSpecificAnswerUX("Please enter your street name", "Not the road type")));
        //ADDRESS STREET TYPE
        while (!employee.setStreetType(DRY.requestSpecificAnswer("Please enter your street type")));
        //ADDRESS UNIT NUMBER
        while (!employee.setUnitNumber(DRY.requestSpecificAnswerUX("Please enter your unit number", "You can leave this blank")));
        //ADDRESS CITY
        while (!employee.setCity(DRY.requestSpecificAnswerUX("Please enter your city", "More than two characters")));
        //ADDRESS STATE/PROVINCE
        while (!employee.setStateOrProvince(DRY.requestSpecificAnswer("Please enter your province").toUpperCase()));
        //ADDRESS POSTAL CODE
        while (!employee.setPostal(DRY.requestSpecificAnswerUX("Please enter your postal code", "X0X0X0 or X#X #X#")));
        //MARITIAL STATUS
        while (!employee.setMaritalStatus(DRY.requestSpecificAnswerUX("Please enter your maritial status", "Will default to Single if empty")));
        //BIRTHDAY
        while (!employee.setBirthday(DRY.requestSpecificAnswerUX("Please enter your birthday", "YYYY/MM/DD")));
        //PHONE NUMBER
        while (!employee.setPhoneNumber(DRY.requestSpecificAnswerUX("Please enter your phone number", "### ### ####")));
        //EMAIL
        while (!employee.setEmail(DRY.requestSpecificAnswer("Please enter your email")));
        //SIN
        while (!employee.setSocialInsuranceNumber(DRY.requestSpecificAnswerUX("Please enter your SIN", "### ### ###")));
        //HIRING DATE
        while (!employee.setHireDate(DRY.requestSpecificAnswerUX("Please enter the hiring date", "YYYY/MM/DD")));
        //JOB TITLE
        while (!employee.setJobTitle(DRY.requestSpecificAnswer("Please enter your job title")));
        //JOB DESCRIPTION
        while (!employee.setJobDescription(DRY.requestSpecificAnswer("Please enter your job description")));
    }

    private static void createHourly(HourlyEmployee employee) {
        while (!employee.setHoursWorked(DRY.requestRealNumber("Please enter the number of hours worked", 0, 168)));
        while (!employee.setHourlyRateDollar(DRY.requestInteger("What is the nueric dollar hourly rate", 11, 100)));
        while (!employee.setHourlyRateCents(DRY.requestInteger("What is the numeric cent hourly rate?", 0, 99)));
    }

    //    while(!employee.set(DRY.requestSpecificAnswer(null)));
    public static void createFullTime(FullTimeEmployee employee) {
        createTeamMember(employee);
        createHourly(employee);
    }

    public static void createPartTime(PartTimeEmployee employee) {
        createTeamMember(employee);
        createHourly(employee);
    }

    public static void createSeasonal(SeasonalEmployee employee) {
        createTeamMember(employee);
        createHourly(employee);
        while (!employee.setTermination(DRY.requestSpecificAnswerUX("Please enter the final date of work", "YYYY/MM/DD")));
    }

    public static void createCommissioned(CommissionedEmployee employee) {
        createTeamMember(employee);
        while (!employee.setCommissionRate(DRY.requestRealNumber("Please enter the commission percentage", 0, 100) / 100));
        while (!employee.setSalesDollar(DRY.requestInteger("Please enter the sales numeric dollar amount", 0, Integer.MAX_VALUE)));
        while (!employee.setSalesCents(DRY.requestInteger("Please enter the sales numeric cent amount", 0, 99)));

    }

    public static void createSalary(SalaryEmployee employee) {
        createTeamMember(employee);
        while (!employee.setSalaryDollars(DRY.requestInteger("Please enter the numeric dollar amount", 0, Integer.MAX_VALUE)));
        while (!employee.setSalaryCents(DRY.requestInteger("Please enter the numeric cent amount", 0, 99)));
    }

    public static void createSalaryPlusCommision(SalaryPlusComissionEmployee employee) {
        createTeamMember(employee);
        while (!employee.setCommissionRate(DRY.requestRealNumber("Please enter the commission percentage", 0, 100) / 100));
        while (!employee.setSalesDollar(DRY.requestInteger("Please enter the sales numeric dollar amount", 0, Integer.MAX_VALUE)));
        while (!employee.setSalesCents(DRY.requestInteger("Please enter the sales numeric cent amount", 0, 99)));
        while (!employee.setSalaryDollars(DRY.requestInteger("Please enter the numeric dollar amount", 0, Integer.MAX_VALUE)));
        while (!employee.setSalaryCents(DRY.requestInteger("Please enter the numeric cent amount", 0, 99)));
    }

}
