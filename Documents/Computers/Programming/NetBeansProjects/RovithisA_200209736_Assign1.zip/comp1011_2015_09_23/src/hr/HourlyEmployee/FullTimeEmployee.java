/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.HourlyEmployee;

import AristotleToolBox.DRY;
import AristotleToolBox.EntityInformation;
import hr.EmpUtility;

/**
 *
 * @author Ari
 */
public class FullTimeEmployee extends HourlyEmployee {

    private final double TAX_RATE = 0.42;

    public FullTimeEmployee() {
        super();
    }

    public FullTimeEmployee(String firstName, String lastName, String unitNumber,
            int streetNumber, String streetName, String streetType, String city,
            String stateOrProvince, String postal, String gender,
            String maritialStatus, String birthday, String phoneNumber,
            String email, String socialInsuranceNumber, String hireDate,
            String termination, String jobTitle,
            String jobDescription, double hours, int hourlyRateDollar, int hourlyRateCents) {
        super(firstName, lastName, unitNumber,
                streetNumber, streetName, streetType, city,
                stateOrProvince, postal, gender,
                maritialStatus, birthday, phoneNumber,
                email, socialInsuranceNumber, hireDate,
                termination, jobTitle,
                jobDescription, hours, hourlyRateDollar, hourlyRateCents);

    }

    /**
     * output all information about the employee with a String.format message
     *
     * @return all information center justified
     */
    @Override
    public String toString() {
        return String.format("%s%n"
                + "%18s%s%n",
                super.toString(),
                "Hourly Rate: ",EntityInformation.changeMoneyToString(new int[]{this.getPayDollar(), this.getPayCent()}));
    }

    @Override
    public boolean calculateEarnings() {
        if ((this.getHourlyRateDollar() != 0 || this.getHourlyRateCents() != 0)
                && this.getHoursWorked() != 0) {
            this.setHourlyRateDollar((int) (this.getHourlyRateDollar() * this.getHoursWorked() / (1 + TAX_RATE)));
            this.setHourlyRateCents((int) (this.getHourlyRateCents() * this.getHoursWorked() / (1 + TAX_RATE)));
            int[] carrier = EmpUtility.formatMoney(getPayDollar(), getPayCent());
            setPayDollar(carrier[0]);
            setPayCent(carrier[1]);
            return true;
        }
        if (this.getHoursWorked() == 0) {
            DRY.errorMsg(new String[]{"They employee did not work this week", "Zero hours put in"});
        }
        if (this.getHourlyRateDollar() == 0 && this.getHourlyRateCents() == 0) {
            DRY.errorMsg(new String[]{"Somehow your employee's Hourly rate was set to $0.00", "No Rate error"});
        }
        return false;
    }

    @Override
    public int[] getEarnings() {
        return new int[]{this.getPayDollar(), this.getPayCent()};
    }
}
