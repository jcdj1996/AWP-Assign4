package hr;

import AristotleToolBox.*;
import java.util.*;

/**
 * @author Ari
 * @version 1.0.0 Employee Class contains information about how to deal with Employees
 */
public abstract class Employee {

    // CLASS VARIABLES **************************************************************************
    //Setting these makes sure that exceptions aren't throw, espciall that tricky nullPointerException
    private String firstName = "";
    private String lastName = "";
    private String unitNumber = "";
    private int streetNumber = 0;
    private String streetName = "";
    private String streetType = "";
    private String city = "";
    private String stateOrProvince = "";
    private String postal = "";
    private String gender = "";
    private String maritalStatus = "";
    private GregorianCalendar birthday = new GregorianCalendar(0, 0, 0);
    private String phoneNumber = "";
    private String email = "";
    private String socialInsuranceNumber = "";
    private GregorianCalendar hireDate = new GregorianCalendar(0, 0, 0);
    private GregorianCalendar termination = new GregorianCalendar(0, 0, 0);
    private int employeeID = 0;
    private String jobTitle = "";
    private String jobDescription = "";

    // CONSTRUCTORS **********************************************************************
    /**
     * Blank constructor
     */
    public Employee() {
    }

    /**
     * Full constructor of all initializing variables
     *
     * @param firstName
     * @param lastName
     * @param unitNumber
     * @param streetNumber
     * @param streetName
     * @param streetType
     * @param city
     * @param stateOrProvince
     * @param postal
     * @param gender
     * @param maritialStatus
     * @param birthday
     * @param phoneNumber
     * @param email
     * @param socialInsuranceNumber
     * @param hireDate
     * @param termination
     * @param jobTitle
     * @param jobDescription
     */
    public Employee(String firstName, String lastName, String unitNumber,
            int streetNumber, String streetName, String streetType, String city,
            String stateOrProvince, String postal, String gender,
            String maritialStatus, String birthday, String phoneNumber,
            String email, String socialInsuranceNumber, String hireDate,
            String termination, String jobTitle,
            String jobDescription) {
        this.setFirstName(firstName);
        this.setLastName(lastName);
        this.setUnitNumber(unitNumber);
        this.setStreetNumber(streetNumber);
        this.setStreetName(streetName);
        this.setStreetType(streetType);
        this.setCity(city);
        this.setStateOrProvince(stateOrProvince);
        this.setPostal(postal);
        this.setGender(gender);
        this.setMaritalStatus(maritalStatus);
        this.setBirthday(birthday);
        this.setPhoneNumber(phoneNumber);
        this.setEmail(email);
        this.setSocialInsuranceNumber(socialInsuranceNumber);
        this.setHireDate(hireDate);
        this.setTermination(termination);
        this.setEmployeeID();
        this.setJobTitle(jobTitle);
        this.setJobDescription(jobDescription);
    }

    // GETTERS *************************************************************
    /**
     * Returns the employees first name
     *
     * @return the employees first name
     */
    public final String getFirstName() {
        return this.firstName;
    }

    /**
     * returns the last name of an employee
     *
     * @return employees last name
     */
    public final String getLastName() {
        return this.lastName;
    }

    /**
     * returns the unit number, if the unit number is empty/null a blank space is returned
     *
     * @return blank if the record is empty else returns the unit number
     */
    public final String getUnitNumber() {
        return this.unitNumber;
    }

    /**
     * returns the street number of the employee
     *
     * @return the street number of the employee
     */
    public final int getStreetNumber() {
        return this.streetNumber;
    }

    /**
     * returns the street name
     *
     * @return the street name record
     */
    public final String getStreetName() {
        return this.streetName;
    }

    /**
     * returns the street type record
     *
     * @return the street type record
     */
    public final String getStreetType() {
        return this.streetType;
    }

    /**
     * returns the city portion of an employees address
     *
     * @return the city portion of an employees address
     */
    public final String getCity() {
        return this.city;
    }

    /**
     * returns the state/province record of the employee's address
     *
     * @return the state/province record of the employee's address
     */
    public final String getStateOrProvince() {
        return this.stateOrProvince;
    }

    /**
     * returns the postal code portion of an employee's address
     *
     * @return postal code portion of an employee's address
     */
    public final String getPostal() {
        return this.postal;
    }

    /**
     * returns the gender of the employee
     *
     * @return gender of the employee
     */
    public final String getGender() {
        return this.gender;
    }

    /**
     * returns the marital status record
     *
     * @return marital status record
     */
    public final String getMaritalStatus() {
        return this.maritalStatus;
    }

    /**
     * returns the employees birthday as a date
     *
     * @return the birthday of the employee
     */
    public final GregorianCalendar getBirthday() {
        return this.birthday;
    }

    /**
     * returns the employees phone number
     *
     * @return the employees phone number
     */
    public final String getPhoneNumber() {
        return this.phoneNumber;
    }

    /**
     * returns the email of the employee
     *
     * @return the email of the employee
     */
    public final String getEmail() {
        return this.email;
    }

    /**
     * returns the SIN record for the employee
     *
     * @return the employees SIN
     */
    public final String getSocialInsuranceNumber() {
        return this.socialInsuranceNumber;
    }

    /**
     * returns the date an employee was hired
     *
     * @return the date the employee was hired
     */
    public final GregorianCalendar getHireDate() {
        return this.hireDate;
    }

    /**
     * returns the date an employee was fired
     *
     * @return the date an employee stopped working for the company
     */
    public final GregorianCalendar getTermination() {
        return this.termination;
    }

    /**
     * returns the employees ID number
     *
     * @return the employees worker Id
     */
    public final int getEmployeeID() {
        return this.employeeID;
    }

    /**
     * this method returns the job title of an employee
     *
     * @return the job title of and employee
     */
    public final String getJobTitle() {
        return this.jobTitle;
    }

    // SETTERS *******************************************************
    /**
     * Setter for first name, ensures the field was not left blank.
     *
     * @param firstName - first name of the employee
     * @return true if the update was successful, else false.
     */
    public final boolean setFirstName(String firstName) {
        if (EntityInformation.checkName(firstName)) {
            this.firstName = firstName;
            return true;
        }
        return false;
    }

    /**
     * sets the last name of the employee
     *
     * @param lastName - the last name to be set
     * @return true if the last name was set else false
     */
    public final boolean setLastName(String lastName) {
        if (Check.isRegex(lastName,
                "[A-Z]?[a-z]{0,3}[A-Z]?[a-z]{0,17}",
                new String[]{"You need to have a valid last name", "Last Name Error"},
                new String[]{"Sorry, you didn't enter a last name", "Please tell me your name sir"})) {
            this.lastName = lastName;
            return true;
        }
        return false;
    }

    /**
     * sets the unit number of an employees address if one is inputted else it remains blank
     *
     * @param unitNumber
     * @return true if the unit number is empty else false
     */
    public final boolean setUnitNumber(String unitNumber) {
        if (EntityInformation.checkUnitNumber(unitNumber)) {
            this.unitNumber = unitNumber;
            return true;
        }
        this.unitNumber = "";
        return false;

    }

    /**
     * sets the street number of the employees address information
     *
     * @param streetNumber street number/house number of the employee
     * @return true if the record was updates else false
     */
    public final boolean setStreetNumber(int streetNumber) {
        if (EntityInformation.checkStreetNumber(streetNumber)) {
            this.streetNumber = streetNumber;
            return true;
        }
        return false;
    }

    /**
     * sets the street name portion on and employees address
     *
     * @param streetName
     * @return true if the record was updated else false
     */
    public final boolean setStreetName(String streetName) {
        if (EntityInformation.checkStreetName(streetName)) {
            this.streetName = streetName;
            return true;
        }
        return false;
    }

    /**
     * sets the street type of the employees address
     *
     * @param streetType - the street type to e updated
     * @return true if the record was updated else false.
     */
    // this list will refer to this website in the future 
    // https://www.canadapost.ca/tools/pg/manual/PGaddress-e.asp?ecid=murl10006450#1423617
    public final boolean setStreetType(String streetType) {
        if (EntityInformation.checkStreetType(streetType)) {
            this.streetType = streetType;
            return true;
        }
        return false;
    }

    /**
     * sets the city portion of an employees address
     *
     * @param city the city to be stored
     * @return true if the record was updated else false
     */
    public final boolean setCity(String city) {
        if (EntityInformation.checkCity(city)) {
            this.city = city;
            return true;
        }
        return false;
    }

    /**
     * sets the state/province portion of an employee's address
     *
     * @param stateOrProvince the state/province to be entered
     * @return true if the record was updated, else false
     */
    public final boolean setStateOrProvince(String stateOrProvince) {
        stateOrProvince = EntityInformation.changeProvince(stateOrProvince);
        if (EntityInformation.checkStateOrProvince(stateOrProvince)) {
            this.stateOrProvince = stateOrProvince;
            return true;
        }
        return false;
    }

    /**
     * sets the postal code portion of the employee's address
     *
     * @param postal the postal code to be stored
     * @return ture if the record updated successfully, else false
     */
    public final boolean setPostal(String postal) {
        if (EntityInformation.checkPostal(postal)) {
            this.postal = postal;
            return true;
        }
        return false;
    }

    /**
     * sets the gender of the employee, either standard or not disclosed to be PC
     *
     * @param gender the gender to be stored
     * @return true if the record is updated, else false
     */
    public final boolean setGender(String gender) {
        gender = EmpUtility.changeGender(gender);
        if (Check.isNotEmptyString(gender,
                new String[]{"You need to have a valid Gender", "Invalid Gender Entereed"})) {
            this.gender = gender;
            return true;
        }
        return false;
    }

    /**
     * sets the marital status of an employee
     *
     * @param maritalStatus the marital status to be
     * @return
     */
    public final boolean setMaritalStatus(String maritalStatus) {
        if (Check.isNotEmptyString(EmpUtility.checkMS(maritalStatus),
                new String[]{"You have entered an invalid maritial status I have defaulted yours to Single", "You are Single! Party!"})) {
            this.maritalStatus = maritalStatus;
            return true;
        }
        this.maritalStatus = "Single";
        return true;
    }

    /**
     * sets the birthday of the employee
     *
     * @param date the birthday to be stored
     * @return true if the record updated, else false
     */
    public final boolean setBirthday(String date) {
        if (Check.isDateYYYYMMDD(date)) {
            this.birthday = DRY.changetoDate(date);
            return true;
        }

        return false;
    }

    /**
     * sets the employees phone number
     *
     * @param phoneNumber - the phone number to be stored
     * @return true if record is set, else false
     */
    public final boolean setPhoneNumber(String phoneNumber) {
        if (EntityInformation.checkPhoneNumber(phoneNumber)) {
            this.phoneNumber = phoneNumber;
            return true;
        }
        return false;
    }

    /**
     * sets the email record for the employee
     *
     * @param email the email to be recorded
     * @return true if successful else false
     */
    public final boolean setEmail(String email) {
        if (EntityInformation.checkEmail(email)) {
            this.email = email;
            return true;
        }
        return false;
    }

    /**
     * sets the social insurance number record for the employee
     *
     * @param socialInsuranceNumber the SIN to be recorded
     * @return true i the record is updated else false
     */
    public final boolean setSocialInsuranceNumber(String socialInsuranceNumber) {
        if (Check.isRegex(socialInsuranceNumber,
                "[\\d]{3}[' ''-']?[\\d]{3}[' ''-']?[\\d]{3}",
                new String[]{"You need to have a valid SIN",
                    "Invalid SIN Entereed"},
                new String[]{"You need to enter a SIN",
                    "Blank SIN Entereed"})) {
            this.socialInsuranceNumber = socialInsuranceNumber;
            return true;
        }
        return false;
    }

    /**
     * this method sets the hire date of the employee
     *
     * @param date the date the employee was hired
     * @return true if the record is updated else false
     */
    public final boolean setHireDate(String date) {
        if (Check.isDateYYYYMMDD(date)) {
            this.hireDate = DRY.changetoDate(date);
            return true;
        }
        DRY.errorMsg(new String[]{"You must enter a date!", "Blank Date Error"});
        return false;
    }

    /**
     * This sets the record for a termination of work of an employee
     *
     * @param date the date an employee ceased working
     * @return true if the date is a success, else false
     */
    public final boolean setTermination(String date) {
        if (Check.isDateYYYYMMDD(date)) {
            this.termination = DRY.changetoDate(date);
            return true;
        }
        DRY.errorMsg(new String[]{"You must enter a date!", "Blank Date Error"});
        return false;
    }

    /**
     * sets the employee ID for an employee
     *
     * @return true if the record was updated else false
     */
    public final boolean setEmployeeID() {
        if (this.getEmployeeID() != 0) {
            System.out.println("This Employee already has an ID number");
            return false;
        }
        this.employeeID = EmpUtility.incrementEmpID();
        return true;
    }

    /**
     * this sets the job title record for the employee
     *
     * @param jobTitle the job title of the employee
     * @return true if the record is updated else false
     */
    public final boolean setJobTitle(String jobTitle) {
        if (Check.isNotEmptyString(jobTitle,
                new String[]{"You have to entered a blank Job Title", "Blank Job Title Error"})) {
            this.jobTitle = jobTitle;
            return true;
        }
        return false;
    }

    /**
     * this method sets the record of job description
     *
     * @param jobDescription contains the job description
     * @return true if the record is updated else false
     */
    public final boolean setJobDescription(String jobDescription) {
        if (Check.isNotEmptyString(jobDescription,
                new String[]{"You have to entered blank Job Description", "Blank Job Description Error"})) {
            this.jobDescription = jobDescription;
            return true;
        }
        return false;
    }

    /**
     * this method returns the job description
     *
     * @return the job description
     */
    public final String getJobDescription() {
        return this.jobDescription;
    }

    // OUTPUT METHODS ***********************************************************
    /**
     * outputs the information about the employee
     *
     * @return the information about the employee in tiny left justified space (hard to read)
     */
    @Override
    public String toString() {
        return String.format(
                "%18s%s %s (%s)%n" //Name
                + "%18s%s%d %s %s%n" //Address
                + "%27s %s, %s%n" //Address Line 2
                + "%18s%s%n" //Status
                + "%18s%s%n" // Birthday
                + "%18s%s%n" // Phone
                + "%18s%s%n" //Email
                + "%18s%s%n" // SIN
                + "%18s%s%n" // Hire
                + "%18s%s%n" // Fire
                + "%18s%s%n" // EmpId
                + "%18s%s%n" // Job Title
                + "%18s%s%n", // Job Description 
                "Name: ", this.getFirstName(), this.getLastName(), this.getGender(),
                "Address: ", this.getUnitNumber(), this.getStreetNumber(), this.getStreetName(), this.getStreetType(),
                this.getCity(), this.getStateOrProvince(),
                this.getPostal(),
                "Maritial Status: ", this.getMaritalStatus(),
                "Birthday: ", DRY.sendDate(this.getBirthday()),
                "Phone Number: ", this.getPhoneNumber(),
                "Email: ", this.getEmail(),
                "SIN: ", this.getSocialInsuranceNumber(),
                "Hire Date: ", DRY.sendDate(this.getHireDate()),
                "Termination Date: ", DRY.sendDate(this.getTermination()),
                "Employee ID: ", this.getEmployeeID(),
                "Job Title: ", this.getJobTitle(),
                "Job Description: ", this.getJobDescription()
        );
    }

    // ABSTRACT METHODS ***********************************************************
    public abstract boolean calculateEarnings();

    public abstract int[] getEarnings();

}
