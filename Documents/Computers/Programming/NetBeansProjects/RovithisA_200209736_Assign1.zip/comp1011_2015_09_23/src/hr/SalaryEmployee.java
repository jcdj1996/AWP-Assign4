package hr;

import AristotleToolBox.Check;
import AristotleToolBox.DRY;
import AristotleToolBox.EntityInformation;

/**
 *
 * @author Ari
 */
public class SalaryEmployee extends Employee {

    int salaryDollars = 0;
    int salaryCents = 0;

    public SalaryEmployee() {
        super();
    }

    public SalaryEmployee(String firstName, String lastName, String unitNumber,
            int streetNumber, String streetName, String streetType, String city,
            String stateOrProvince, String postal, String gender,
            String maritialStatus, String birthday, String phoneNumber,
            String email, String socialInsuranceNumber, String hireDate,
            String termination, String jobTitle,
            String jobDescription, int salaryDollars, int salaryCents) {
        super(firstName, lastName, unitNumber,
                streetNumber, streetName, streetType, city,
                stateOrProvince, postal, gender,
                maritialStatus, birthday, phoneNumber,
                email, socialInsuranceNumber, hireDate,
                termination, jobTitle,
                jobDescription);
        this.setSalaryDollars(salaryDollars);
        this.setSalaryCents(salaryCents);
    }

    public final int getSalaryDollars() {
        return salaryDollars;
    }

    public final int getSalaryCents() {
        return salaryCents;
    }

    public final boolean setSalaryDollars(int salaryDollars) {
        if (Check.isWholeNumber(salaryDollars)) {
            this.salaryDollars = salaryDollars;
            return true;
        }
        return false;
    }

    public final boolean setSalaryCents(int salaryCents) {
        if (Check.isWholeNumber(salaryDollars)) {
            this.salaryCents = salaryCents;
            return true;
        }
        return false;
    }

    /**
     * output all information about the employee with a String.format message
     *
     * @return all information center justified
     */
    @Override
    public final String toString() {
        return String.format("%s%n" //original
                + "%18s%s%n" //Salary
                + "%18s%s%n", //total pay
                super.toString(),
                "Salary: ", EntityInformation.changeMoneyToString(new int[]{this.getSalaryDollars(), this.getSalaryCents()}),
                "Total pay: ", EntityInformation.changeMoneyToString(new int[]{this.getEarnings()[0], this.getEarnings()[1]})
        );
    }

    @Override
    public final boolean calculateEarnings() {
        if (getSalaryDollars() != 0 || getSalaryCents() != 0) {
            int[] carrier = EmpUtility.formatMoney(getSalaryDollars(), getSalaryCents());
            setSalaryDollars(carrier[0]);
            setSalaryCents(carrier[1]);
            return true;
        }
        if (getSalaryDollars() == 0 && getSalaryCents() == 0) {
            DRY.errorMsg(new String[]{"You have entered $0.00 in salary", "No Salary"});
        }
        return false;
    }

    @Override
    public final int[] getEarnings() {
        return new int[]{getSalaryDollars(), getSalaryCents()};
    }

}
