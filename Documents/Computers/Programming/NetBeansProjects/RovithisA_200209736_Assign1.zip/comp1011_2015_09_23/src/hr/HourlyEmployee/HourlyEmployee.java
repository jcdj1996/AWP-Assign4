package hr.HourlyEmployee;

import AristotleToolBox.Check;
import AristotleToolBox.EntityInformation;
import hr.EmpUtility;
import hr.Employee;

/**
 *
 * @author Ari
 */
public abstract class HourlyEmployee extends Employee {

    //http://www.statcan.gc.ca/eng/concepts/definitions/labour-class03b
    private final double OVERTIME_INCREASE = 1.5;
    private double hoursWorked;
    private int hourlyRateDollar;
    private int hourlyRateCents;
    private int payDollar;
    private int payCent;

    public HourlyEmployee() {
        super();
    }

    public HourlyEmployee(String firstName, String lastName, String unitNumber,
            int streetNumber, String streetName, String streetType, String city,
            String stateOrProvince, String postal, String gender,
            String maritialStatus, String birthday, String phoneNumber,
            String email, String socialInsuranceNumber, String hireDate,
            String termination, String jobTitle,
            String jobDescription, double hours, int hourlyRateDollar, int hourlyRateCents) {
        super(firstName, lastName, unitNumber,
                streetNumber, streetName, streetType, city,
                stateOrProvince, postal, gender,
                maritialStatus, birthday, phoneNumber,
                email, socialInsuranceNumber, hireDate,
                termination, jobTitle,
                jobDescription);
        this.setHoursWorked(hours);
        this.setHourlyRateDollar(hourlyRateDollar);
        this.setHourlyRateCents(hourlyRateCents);
    }

    public final double getHoursWorked() {
        return this.hoursWorked;
    }

    public final int getHourlyRateDollar() {
        return hourlyRateDollar;
    }

    public final int getHourlyRateCents() {
        return hourlyRateCents;
    }

    public final int getPayDollar() {
        return payDollar;
    }

    public final int getPayCent() {
        return payCent;
    }

    public final boolean setHoursWorked(double hours) {
        if (Check.isRealNumber(String.valueOf(hours))) {
            this.hoursWorked = hours;
            return true;
        }
        return false;
    }

    public final boolean setHourlyRateDollar(int hourlyRateDollar) {
        if (Check.isWholeNumber(hourlyRateDollar)) {
            this.hourlyRateDollar = hourlyRateDollar;
            return true;
        }
        return false;
    }

    public final boolean setHourlyRateCents(int hourlyRateCents) {
        if (Check.isWholeNumber(hourlyRateCents)) {
            this.hourlyRateCents = hourlyRateCents;
            return true;
        }
        return false;
    }

    public final boolean setPayDollar(int payDollar) {
        if (Check.isWholeNumber(payDollar)) {
            this.payDollar = payDollar;
            return true;
        }
        return false;
    }

    public final boolean setPayCent(int payCent) {
        if (Check.isWholeNumber(payCent)) {
            this.payCent = payCent;
            return true;
        }
        return false;
    }

    public final int[] getHourlyRate() {
        return new int[]{this.getHourlyRateDollar(), this.getHourlyRateCents()};
    }

     /**
     * output all information about the employee with a String.format message
     *
     * @return all information center justified
     */
    @Override
    public String toString() {
        return String.format("%s%n"//original
                + "%18s%s%n" //hourly rate
                + "%18s%s%n",//hours worked
                super.toString(),
                "Hourly Rate: ", EntityInformation.changeMoneyToString(EmpUtility.formatMoney(this.getHourlyRate()[0], this.getHourlyRate()[1])),
                "Hours Worked: ", this.getHoursWorked()
        );
    }

    @Override
    public abstract boolean calculateEarnings();

    @Override
    public abstract int[] getEarnings();
}
