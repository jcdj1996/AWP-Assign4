package products;

import AristotleToolBox.Check;
import AristotleToolBox.EntityInformation;

/**
 *
 * @author Ari
 */
public class Product {

    private final double MARK_UP = 1.7;

    private Manufacturer maker;
    private String partName = "";
    private String partNumber = "";
    private String partDescription = "";
    private String supplier = "";
    private String supplierPartNumber = "";
    private String unitOfMeasure = "";
    private int costDollar = 0;
    private int costCents = 0;
    private int salePriceDollar = 0;
    private int salePriceCents = 0;

    public Product(){
    }
    
    /**
     * @param partName
     * @param partNumber
     * @param partDescription
     * @param supplier
     * @param supplierPartNumber
     * @param unitOfMeasure
     * @param costDollar
     * @param costCents
     * @param salePriceDollar
     * @param salePriceCents
     */
    public Product(String partName, String partNumber, String partDescription, String supplier,
            String supplierPartNumber, String unitOfMeasure, int costDollar,
            int costCents, int salePriceDollar, int salePriceCents/*, File drawing, File materialDataSheet*/) {
        this.partName = partName;
        this.partNumber = partNumber;
        this.partDescription = partDescription;
        this.supplier = supplier;
        this.supplierPartNumber = supplierPartNumber;
        this.unitOfMeasure = unitOfMeasure;
        this.costDollar = costDollar;
        this.costCents = costCents;
        this.salePriceDollar = salePriceDollar;
        this.salePriceCents = salePriceCents;
    }

    public final Manufacturer getMaker() {
        return maker;
    }

    public final String getPartName() {
        return partName;
    }

    public final String getPartNumber() {
        return partNumber;
    }

    public final String getPartDescription() {
        return partDescription;
    }

    public final String getSupplier() {
        return supplier;
    }

    public final String getSupplierPartNumber() {
        return supplierPartNumber;
    }

    public final String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public final int getCostDollar() {
        return costDollar;
    }

    public final int getCostCents() {
        return costCents;
    }

    public final int getSalePriceDollar() {
        return salePriceDollar;
    }

    public final int getSalePriceCents() {
        return salePriceCents;
    }

    public final boolean setMaker(Manufacturer maker) {
        this.maker = maker;
        return true;

    }

    public final boolean setPartName(String partName) {
        if (EntityInformation.checkName(partName)) {
            this.partName = partName;
            return true;
        }
        return false;
    }

    public final boolean setPartNumber(String partNumber) {
        if (EntityInformation.checkName(partNumber)) {
            this.partNumber = partNumber;
            return true;
        }
        return false;
    }

    public final boolean setPartDescription(String partDescription) {
        if (EntityInformation.checkName(partDescription)) {
            this.partDescription = partDescription;
            return true;
        }
        return false;
    }

    public final boolean setSupplier(String supplier) {
        if (EntityInformation.checkName(supplier)) {
            this.supplier = supplier;
            return true;
        }
        return false;
    }

    public final boolean setSupplierPartNumber(String supplierPartNumber) {
        if (EntityInformation.checkName(supplierPartNumber)) {
            this.supplierPartNumber = supplierPartNumber;
            return true;
        }
        return false;
    }

    public final boolean setUnitOfMeasure(String unitOfMeasure) {
        if (EntityInformation.checkName(unitOfMeasure)) {
            this.unitOfMeasure = unitOfMeasure;
            return true;
        }
        return false;
    }

    public final boolean setCostDollar(int costDollar) {
        if (Check.isWholeNumber(costDollar)) {
            this.costDollar = costDollar;
            return true;
        }
        return false;
    }

    public final boolean setCostCents(int costCents) {
        if (Check.isWholeNumber(costCents)) {
            this.costCents = costCents;
            return true;
        }
        return false;
    }

    public final boolean setSalePriceDollar(int salePriceDollar) {
        if (Check.isWholeNumber(salePriceDollar)) {
            this.salePriceDollar = salePriceDollar;
            return true;
        }
        return false;
    }

    public final boolean setSalePriceCents(int salePriceCents) {
        if (Check.isWholeNumber(salePriceCents)) {
            this.salePriceCents = salePriceCents;
            return true;
        }
        return false;
    }

}
