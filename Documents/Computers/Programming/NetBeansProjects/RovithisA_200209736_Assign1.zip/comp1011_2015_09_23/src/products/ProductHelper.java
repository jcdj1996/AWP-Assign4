/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package products;

import AristotleToolBox.DRY;
import java.util.ArrayList;

/**
 *
 * @author Ari
 */
public class ProductHelper {

    public static void createProduct(Product product, ArrayList<Manufacturer> manuList) {
        boolean exit = false;
        while (!product.setPartName(DRY.requestSpecificAnswer("Please enter the part's name")));
        while (!product.setPartNumber(DRY.requestSpecificAnswer("Please enter the part's number")));
        while (!product.setPartDescription(DRY.requestSpecificAnswer("Please enter the part's description")));
        while (!product.setSupplier(DRY.requestSpecificAnswer("Please enter this part's supllier")));
        while (!product.setSupplierPartNumber(DRY.requestSpecificAnswer("Please enter this supplier's part number")));
        while (!product.setUnitOfMeasure(DRY.requestSpecificAnswer("How is this item measured")));
        while (!product.setCostDollar(DRY.requestInteger("What is the numeric dollar cost of this part", 0, 9999)));
        while (!product.setCostCents(DRY.requestInteger("What is the numeric cent cost of this part", 0, 99)));
        do {
            switch (DRY.requestSpecificAnswerUX("Would you like to create a new manufacturer or select one from a list?", 0 + " " + 1)) {
                case "0":
                    manuList.add(createManufacturer());
                    product.setMaker(manuList.get(manuList.size()-1));
                    exit = true;
                    break;
                case "1":
                     product.setMaker(selectManufacturer(product, manuList));
                    exit = true;
                    break;
                default:
                    DRY.errorMsg(new String[]{"Please enter either 0 or 1", null});
            }
        } while (!exit);
    }

    private static Manufacturer createManufacturer() {
        Manufacturer manu = new Manufacturer();
        //NAME 
        while (!manu.setName(DRY.requestSpecificAnswer("What is the Manufacturer's name: ")));
        //ADDRESS UNIT NUMBER 
        while (!manu.setUnitNumber(DRY.requestSpecificAnswerUX("Please enter " + manu.getName() + "'s unit number", "You can leave this blank")));
        //ADDRESS STREET NUMBER
        while (!manu.setStreetNumber(DRY.requestInteger("Please enter " + manu.getName() + "'s street number", 1, Integer.MAX_VALUE)));
        //ADDRESS STREET NAME
        while (!manu.setStreetName(DRY.requestSpecificAnswerUX("Please enter " + manu.getName() + "'s street name", "Not the road type")));
        //ADDRESS STREET TYPE
        while (!manu.setStreetType(DRY.requestSpecificAnswer("Please enter " + manu.getName() + "'s street type")));
        //ADDRESS CITY
        while (!manu.setCity(DRY.requestSpecificAnswerUX("Please enter " + manu.getName() + "'s city", "More than two characters")));
        //ADDRESS STATE/PROVINCE
        while (!manu.setStateOrProvince(DRY.requestSpecificAnswer("Please enter " + manu.getName() + "'s province").toUpperCase()));
        //ADDRESS POSTAL CODE
        while (!manu.setPostal(DRY.requestSpecificAnswerUX("Please enter " + manu.getName() + "'s postal code", "X0X0X0 or X#X #X#")));
        //PHONE NUMBER
        while (!manu.setPhoneNumber(DRY.requestSpecificAnswerUX("Please enter " + manu.getName() + "'s phone number", "### ### ####")));
        //EMAIL
        while (!manu.setEmail(DRY.requestSpecificAnswer("Please enter " + manu.getName() + "'s email")));

        return manu;
    }

    private static Manufacturer selectManufacturer(Product product, ArrayList<Manufacturer> manu) {
        int i;
        boolean exit = false;
        int carrier = 0;
        do {
            i = -1;
            System.out.println("Which Manufacturer makes this product? ");
            System.out.println("0: Exit");
            for (Manufacturer m : manu) {
                System.out.println((++i + 1) + ": " + m.getName());
            }
            System.out.println();
            for (int count = -1; count < 3; ++count) {
                carrier = DRY.requestInteger("Please make a selection", 1, i + 1);
                if (carrier >= 1 && carrier <= i + 1) {
                    exit = true;
                    break;
                }
            }
        } while (!exit);
        if (carrier - 1 < 0) {
            return null;
        }
        return manu.get(carrier - 1);
    }
}
