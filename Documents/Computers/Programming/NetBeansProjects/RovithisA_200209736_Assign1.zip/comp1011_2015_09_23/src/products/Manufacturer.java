/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package products;

import AristotleToolBox.EntityInformation;

/**
 *
 * @author Ari
 */
public class Manufacturer {

    private String name = "";
    private String unitNumber = "";
    private int streetNumber = 0;
    private String streetName = "";
    private String streetType = "";
    private String city = "";
    private String stateOrProvince = "";
    private String postal = "";
    private String phoneNumber = "";
    private String email = "";

    public Manufacturer() {
    }

    public Manufacturer(String name, String unitNumber, int streetNumber, String streetName,
            String streetType, String city, String stateOrProvince, String postal) {
         this.setName(name);
         this.setUnitNumber(unitNumber);
         this.setStreetNumber(streetNumber);
         this.setStreetName(streetName);
         this.setStreetType(streetType);
         this.setCity(city);
         this.setStateOrProvince(stateOrProvince);
         this.setPostal(postal);
    }


    public final String getName() {
        return name;
    }

    public final String getUnitNumber() {
        return unitNumber;
    }

    public final int getStreetNumber() {
        return streetNumber;
    }

    public final String getStreetName() {
        return streetName;
    }

    public final String getStreetType() {
        return streetType;
    }

    public final String getCity() {
        return city;
    }

    public final String getStateOrProvince() {
        return stateOrProvince;
    }

    public final String getPostal() {
        return postal;
    }

    public final String getPhoneNumber() {
        return phoneNumber;
    }

    public final String getEmail() {
        return email;
    }

    public final boolean setName(String name) {
        if (EntityInformation.checkName(name)) {
            this.name = name;
            return true;
        }
        return false;
    }

    public final boolean setUnitNumber(String unitNumber) {
        if (EntityInformation.checkUnitNumber(unitNumber)) {
            this.unitNumber = unitNumber;
            return true;
        }
        return false;
    }

    public final boolean setStreetNumber(int streetNumber) {
        if (EntityInformation.checkStreetNumber(streetNumber)) {
            this.streetNumber = streetNumber;
            return true;
        }
        return false;
    }

    public final boolean setStreetName(String streetName) {
        if (EntityInformation.checkStreetName(streetName)) {
            this.streetName = streetName;
            return true;
        }
        return false;
    }

    public final boolean setStreetType(String streetType) {
        if (EntityInformation.checkStreetType(streetType)) {
            this.streetType = streetType;
            return true;
        }
        return false;
    }

    public final boolean setCity(String city) {
        if (EntityInformation.checkCity(city)) {
            this.city = city;
            return true;
        }
        return false;
    }

    public final boolean setStateOrProvince(String stateOrProvince) {
        if (EntityInformation.checkStateOrProvince(stateOrProvince)) {
            this.stateOrProvince = stateOrProvince;
            return true;
        }
        return false;
    }

    public final boolean setPostal(String postal) {
        if (EntityInformation.checkPostal(postal)) {
            this.postal = postal;
            return true;
        }
        return false;
    }

    public final boolean setPhoneNumber(String phoneNumber) {
        if (EntityInformation.checkPhoneNumber(phoneNumber)) {
            this.phoneNumber = phoneNumber;
            return true;
        }
        return false;
    }

    public final boolean setEmail(String email) {
        if (EntityInformation.checkEmail(email)) {
            this.email = email;
            return true;
        }
        return false;
    }

}
