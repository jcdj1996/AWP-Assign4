package Store;

import java.util.ArrayList;
import products.Product;
import hr.*;
import hr.HourlyEmployee.*;
import products.Manufacturer;

/**
 *
 * @author Ari
 */
public class Tester {

    private static ArrayList<Employee> employees = new ArrayList<>();
    private static ArrayList<Product> products = new ArrayList<>();
    private static ArrayList<Manufacturer> manufacturers = new ArrayList<>();

    public static void main(String[] args) {

        employees.add(new SalaryEmployee());
        employees.get(0).setFirstName("Ari");
        employees.get(0).setLastName("Rovithis");
        employees.get(0).setUnitNumber("");
        employees.get(0).setStreetNumber(3065);
        employees.get(0).setStreetName("Fourth");
        employees.get(0).setStreetType("Line");
        employees.get(0).setCity("Cookstown");
        employees.get(0).setStateOrProvince("ON");
        employees.get(0).setPostal("N6G 1L7");
        employees.get(0).setGender("M");
        employees.get(0).setMaritalStatus("Single");
        employees.get(0).setBirthday("1988/12/24");
        employees.get(0).setPhoneNumber("+1 705 234 5678");
        employees.get(0).setEmail("Aristotle.Rovithis@MyGeorgian.ca");
        employees.get(0).setSocialInsuranceNumber("123456789");
        employees.get(0).setHireDate("1988/12/24");
        employees.get(0).setTermination("1988/11/24");
        employees.get(0).setEmployeeID();
        employees.get(0).setJobTitle("Cook");
        employees.get(0).setJobDescription("Eat a banana");

        employees.add(new CommissionedEmployee());
        employees.get(1).setFirstName("Irin");
        employees.get(1).setLastName("Avery");
        employees.get(1).setUnitNumber("A");
        employees.get(1).setStreetNumber(123);
        employees.get(1).setStreetName("Any");
        employees.get(1).setStreetType("Street");
        employees.get(1).setCity("Barrie");
        employees.get(1).setStateOrProvince("ON");
        employees.get(1).setPostal("L0L1L9");
        employees.get(1).setGender("M");
        employees.get(1).setMaritalStatus("Married");
        employees.get(1).setBirthday("1980/07/6");
        employees.get(1).setPhoneNumber("1 705 999 0000");
        employees.get(1).setEmail("Irin.Avery@MyGeorgian.ca");
        employees.get(1).setSocialInsuranceNumber("234567890");
        employees.get(1).setHireDate("2003/11/31");
        employees.get(1).setTermination("2004/11/13");
        employees.get(1).setEmployeeID();
        employees.get(1).setJobTitle("Programmer");
        employees.get(1).setJobDescription("Change coffee into Java");

        employees.add(new SalaryPlusComissionEmployee());
        employees.get(2).setFirstName("Harlan");
        employees.get(2).setLastName("Batchelor");
        employees.get(2).setUnitNumber("b ");
        employees.get(2).setStreetNumber(123);
        employees.get(2).setStreetName("Any");
        employees.get(2).setStreetType("Street");
        employees.get(2).setCity("Barrie");
        employees.get(2).setStateOrProvince("ON");
        employees.get(2).setPostal("L0L1L9");
        employees.get(2).setGender("M");
        employees.get(2).setMaritalStatus("Divorced");
        employees.get(2).setBirthday("1982/09/16");
        employees.get(2).setPhoneNumber("17058763201");
        employees.get(2).setEmail("Harlan.Batchelor@MyGeorgian.ca");
        employees.get(2).setSocialInsuranceNumber("234789456");
        employees.get(2).setHireDate("2004/1/31");
        employees.get(2).setEmployeeID();
        employees.get(2).setJobTitle("Programmer");
        employees.get(2).setJobDescription("Change coffee into Java");

        employees.add(new FullTimeEmployee());
        employees.get(3).setFirstName("Doug");
        employees.get(3).setLastName("Brunner");
        employees.get(3).setUnitNumber("13");
        employees.get(3).setStreetNumber(1323);
        employees.get(3).setStreetName("Main");
        employees.get(3).setStreetType("Drive");
        employees.get(3).setCity("Barrie");
        employees.get(3).setStateOrProvince("ON");
        employees.get(3).setPostal("M4X2T6");
        employees.get(3).setGender("M");
        employees.get(3).setMaritalStatus("Seperated");
        employees.get(3).setBirthday("1981/04/26");
        employees.get(3).setPhoneNumber("1672382341");
        employees.get(3).setEmail("Doug.Brunner@MyGeorgian.ca");
        employees.get(3).setSocialInsuranceNumber("876456123");
        employees.get(3).setHireDate("2002/1/31");
        employees.get(3).setEmployeeID();
        employees.get(3).setJobTitle("Analyst");
        employees.get(3).setJobDescription("Watch others change coffee into Java");

        employees.add(new FullTimeEmployee());
        employees.get(4).setFirstName("Anthony");
        employees.get(4).setLastName("Gobin");
        employees.get(4).setUnitNumber("");
        employees.get(4).setStreetNumber(152);
        employees.get(4).setStreetName("Georgian");
        employees.get(4).setStreetType("Drive");
        employees.get(4).setCity("Barrie");
        employees.get(4).setStateOrProvince("ON");
        employees.get(4).setPostal("Y2T1Q6");
        employees.get(4).setGender("M");
        employees.get(4).setMaritalStatus("Common-Law");
        employees.get(4).setBirthday("1971/02/12");
        employees.get(4).setPhoneNumber("2345671290");
        employees.get(4).setEmail("Anthony.Gobin@MyGeorgian.ca");
        employees.get(4).setSocialInsuranceNumber("123409876");
        employees.get(4).setHireDate("2001/1/31");
        employees.get(4).setEmployeeID();
        employees.get(4).setJobTitle("Analyst");
        employees.get(4).setJobDescription("Watch others change coffee into Java");

        employees.add(new PartTimeEmployee());
        employees.get(5).setFirstName("Morgan");
        employees.get(5).setLastName("Kelly");
        employees.get(5).setUnitNumber("");
        employees.get(5).setStreetNumber(152);
        employees.get(5).setStreetName("Georgian");
        employees.get(5).setStreetType("Drive");
        employees.get(5).setCity("Barrie");
        employees.get(5).setStateOrProvince("ON");
        employees.get(5).setPostal("Y2T1Q6");
        employees.get(5).setGender("M");
        employees.get(5).setMaritalStatus("Common-Law");
        employees.get(5).setBirthday("1974/02/12");
        employees.get(5).setPhoneNumber("2345671290");
        employees.get(5).setEmail("Anthony.Gobin@MyGeorgian.ca");
        employees.get(5).setSocialInsuranceNumber("492876212");
        employees.get(5).setHireDate("2000/1/31");
        employees.get(5).setEmployeeID();
        employees.get(5).setJobTitle("Web Dev");
        employees.get(5).setJobDescription("Paint with the Box Model");

        employees.add(new SeasonalEmployee());
        employees.get(6).setFirstName("Kuba");
        employees.get(6).setLastName("Baczynski");
        employees.get(6).setUnitNumber("");
        employees.get(6).setStreetNumber(200);
        employees.get(6).setStreetName("Northcenter");
        employees.get(6).setStreetType("Road");
        employees.get(6).setCity("London");
        employees.get(6).setStateOrProvince("ON");
        employees.get(6).setPostal("N6H1G3");
        employees.get(6).setGender("M");
        employees.get(6).setMaritalStatus("Single");
        employees.get(6).setBirthday("1950/04/12");
        employees.get(6).setPhoneNumber("111-111-1111");
        employees.get(6).setEmail("zestfullyclean@hotmail.com");
        employees.get(6).setSocialInsuranceNumber("999888777");
        employees.get(6).setHireDate("2015/1/31");
        employees.get(6).setTermination("2016/1/3");
        employees.get(6).setEmployeeID();
        employees.get(6).setJobTitle("Web Dev");
        employees.get(6).setJobDescription("Paint with the Box Model");

        System.out.println("Testing");
        System.out.println("<----");
        new ARIMART(employees, products);
    }
}
