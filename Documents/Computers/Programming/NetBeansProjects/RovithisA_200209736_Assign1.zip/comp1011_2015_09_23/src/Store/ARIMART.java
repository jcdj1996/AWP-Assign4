package Store;

import AristotleToolBox.DRY;
import hr.*;
import hr.HourlyEmployee.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import products.*;
import java.util.ArrayList;

/**
 *
 * @author Ari
 */

/*
 Employee class with all accessor and mutator methods
 Product class with all the accessor and mutator methods
 Main tester/driver class to start the program
 Should provide an option to create a new employee OR enter a new product
 Needs to read all the Employee information from the user (use a Scanner object with a while loop) and create an Employee object
 Needs to read all the Product information from the user (use a Scanner object with a while loop) and create a Product object
 Design a UML class diagram first to identify all the needs you have for these classes.
 */
public class ARIMART {

    /**
     * This is the tester Class for everything! makes sure its all running properly and can be
     * changed to production quality
     *
     * @param args
     */
    //Constants
    private final String BASIC_QUESTION = "Please enter a choice to proceed";

    //Variables
    private static ArrayList<Employee> employees = new ArrayList<>();
    private static ArrayList<Product> products = new ArrayList<>();
    private static ArrayList<Manufacturer> manufacturers = new ArrayList<>();

    //Object Constructor B/c you can have more than one store!
    //Mr. T told me: "(he) pities the foo that doesn't think you can have more than one store"
    public ARIMART() {
    }

    //TESTER CONSTRUCTOR
    public ARIMART(ArrayList<Employee> employeeslist, ArrayList<Product> productslist) {
        ARIMART.employees = employeeslist;
        ARIMART.products = productslist;
        main(null);
    }

    public static void main(String[] args) {
        new ARIMART().mainMenu();
    }

    //main menu
    @SuppressWarnings("empty-statement")
    private void mainMenu() {
        boolean continuum = true;
        do {
            System.out.println("\n--- MAIN MENU ---\n\n"
                    + "1 : Product Menu\n"
                    + "2 : Human Resources\n"
                    + "0 : Terminate Program");
            switch (DRY.requestSpecificAnswer(BASIC_QUESTION)) {

                case "0":   //terminate program
                    continuum = false;
                    break;

                case "1"://product menu
                    while (!productMenu());
                    break;

                case "2":  //human resources
                    while (!humanResourcesMenu());
                    break;

                default: // retry
                    sorry();
            }
        } while (continuum);
        System.out.println("Thank you for using our software!");
    }

    //  product message method
    private boolean productMenu() {
        System.out.println("\n--- PRODUCT MENU ---\n\n"
                + "1: Search products\n"
                + "2: Enter new product\n"
                + "3: Show All Products\n"
                + "0: Exit");
        switch (DRY.requestSpecificAnswer(BASIC_QUESTION)) {

            case "0":   //EXIT
                break;

            case "1"://product search
                searchProducts(DRY.requestSpecificAnswer("Please Enter what you are looking for: "));
                break;

            case "2":   //create product
                products.add(new Product());
                ProductHelper.createProduct(products.get(products.size() - 1), manufacturers);
                break;

            case "3":// show all products
//                showAllProducts();
                showAllList(products);

                break;

            default: //retry
                sorry();
                return false;
        }
        return true;
    }

    // HR message method
    private boolean humanResourcesMenu() {
        System.out.println("\n--- HUMAN RESOURCES MENU ---\n\n"
                + "1: Search employees\n"
                + "2: Enter new employee\n"
                + "3: Show all Employees\n"
                + "0: Exit");
        switch (DRY.requestSpecificAnswer(BASIC_QUESTION)) {

            case "0":     //previous menu
                break;

            case "1": //search employees
                searchEmployees(DRY.requestSpecificAnswer("Please type what you are looking for"));
                break;

            case "2": //new employee
                while (!employeeTypeMenu());
                break;

            case "3": //show all
                //showAllEmployees();
                showAllList(employees);
                break;

            default:  // retry
                sorry();
                return false;
        }
        return true;
    }

    //  HR message method
    private boolean employeeTypeMenu() {
        System.out.println("\n--- EMPLOYEE TYPE MENU ---\n\n"
                + "1: Hourly Employee\n"
                + "2: Salary Employee\n"
                + "3: Commissioned Employee\n"
                + "4: Base plus Commission Employee\n"
                + "0: Exit");
        switch (DRY.requestSpecificAnswer(BASIC_QUESTION)) {

            case "0":        //previous menu
                break;

            case "1": //Hourly
                while (!hourlyEmployeeMenu());
                break;

            case "2":  //Salary
                employees.add(new SalaryEmployee());
                EmpUtility.createSalary((SalaryEmployee) employees.get(employees.size() - 1));

                break;

            case "3":  //Commision
                employees.add(new CommissionedEmployee());
                EmpUtility.createCommissioned((CommissionedEmployee) employees.get(employees.size() - 1));
                break;

            case "4":    //Base plus commision
                employees.add(new SalaryPlusComissionEmployee());
                EmpUtility.createSalary((SalaryEmployee) employees.get(employees.size() - 1));
                break;

            default:
                sorry();
                return false;
        }
        return true;
    }

    private boolean hourlyEmployeeMenu() {
        System.out.println("\n--- EMPLOYEE TYPE MENU ---\n\n"
                + "1: Full Time\n"
                + "2: Part Time\n"
                + "3: Seasonal\n"
                + "0: Exit");
        switch (DRY.requestSpecificAnswer(BASIC_QUESTION)) {

            case "0": //previous menu
                break;

            case "1"://Create full time
                employees.add(new FullTimeEmployee());
                EmpUtility.createFullTime((FullTimeEmployee) employees.get(employees.size() - 1));
                break;

            case "2"://Create part time
                employees.add(new PartTimeEmployee());
                EmpUtility.createPartTime((PartTimeEmployee) employees.get(employees.size() - 1));
                break;

            case "3":     //create seasonal
                employees.add(new SeasonalEmployee());
                EmpUtility.createSeasonal((SeasonalEmployee) employees.get(employees.size() - 1));
                break;

            default:
                sorry();
                return false;
        }
        return true;
    }

    //  Sorry for the error message (all the same so the spelling is nice!
    private void sorry() {
        System.out.println("Sorry I don't recognize that command please try again!");
    }

    private void searchEmployees(String request) {
        String duplicateReturnCheck = "";
        Class c;
        for (Employee element : employees) {
            c = element.getClass();
            do {
                for (Method method : c.getDeclaredMethods()) {
//                String fieldValue = String.valueOf(field).toLowerCase();
                    //  System.out.println((method.getName().substring(0, 3)));
                    if (method.getName().substring(0, 3).equals("get")) {
                        try {
                            if (String.valueOf(method.invoke(element, (Object[]) null)).toLowerCase().contains(request.toLowerCase())
                                    && !element.toString().toLowerCase().equals(duplicateReturnCheck.toLowerCase())
                                    && !(method.getGenericReturnType().getTypeName().equals(java.util.GregorianCalendar.class.getTypeName()))) {
//                                System.out.println("Found in: " + method.getGenericReturnType()
//                                        /*+ "\n" + (method.getGenericReturnType().getTypeName().equals(java.util.GregorianCalendar.class.getTypeName()))*/);
                                System.out.println(element.toString());
                                duplicateReturnCheck = element.toString();
                            }
                        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException z) {
                            System.out.println("Bad method invoke");
                        }
                    }
//                if (fieldValue.contains(request.toLowerCase()) ) {
//                    //if (e.toString().toLowerCase().contains(request.toLowerCase())) {
//                    System.out.println("Record found containing: " + request);
//                    System.out.println(e.toString());
//                    return;
//                }
                }
                c = c.getSuperclass();
            } while (c.getSuperclass() != null);
        }
        System.out.print((duplicateReturnCheck.equals(""))
                ? "Sorry, no records found with that entry.\n"
                : "");
    }

    private void searchProducts(String request) {
        String duplicateReturnCheck = "";
        Class c;
        for (Product element : products) {
            c = element.getClass();
            do {
                for (Method method : element.getClass().getDeclaredMethods()) {
//                String fieldValue = String.valueOf(field).toLowerCase();
                    //  System.out.println((method.getName().substring(0, 3)));
                    if (method.getName().substring(0, 3).equals("get")) {
                        try {
                            //System.out.print((method.getName()) + " Running");
                            if (String.valueOf(method.invoke(element, (Object[]) null)).toLowerCase().contains(request.toLowerCase())
                                    && !element.toString().toLowerCase().equals(duplicateReturnCheck.toLowerCase())
                                    && !(method.getGenericReturnType().getTypeName().equals(java.util.GregorianCalendar.class.getTypeName()))) {
                                System.out.println(element.toString());
                                duplicateReturnCheck = element.toString();
                            }
                        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException z) {
                            System.out.println("FLAG");
                        }
                    }
//                if (fieldValue.contains(request.toLowerCase()) ) {
//                    //if (e.toString().toLowerCase().contains(request.toLowerCase())) {
//                    System.out.println("Record found containing: " + request);
//                    System.out.println(e.toString());
//                    return;
//                }
                }
                c = c.getSuperclass();
            } while (c.getSuperclass() != null);

            System.out.print(
                    (duplicateReturnCheck.equals(""))
                            ? "Sorry, no records found with that entry.\n"
                            : "");
        }
    }

//    private void showAllEmployees() {
//        employees.stream().forEach((e) -> {
//            System.out.println(e.toString());
//            System.out.println();
//        });
//    }
//
//    private void showAllProducts() {
//        products.stream().forEach((p) -> {
//            System.out.println(p.toString());
//            System.out.println();
//        });
//    }
    private void showAllList(ArrayList<?> list) {
        list.stream().forEach((p) -> {
            System.out.println(p.toString());
            System.out.println();
        });
    }

}
